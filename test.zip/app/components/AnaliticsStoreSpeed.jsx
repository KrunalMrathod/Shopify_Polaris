import { BlockStack, Box, Card, Icon, InlineStack, Text } from '@shopify/polaris'
import React from 'react'
import {
    AlertCircleIcon, ArrowUpIcon,
} from '@shopify/polaris-icons';
import StoreSpeedChart from "../components/Charts/StoreSpeedChart"
import StorePerformance from './Charts/StorePerfomance';
export const AnaliticsStoreSpeed = () => {
    return (
        <Box className="SpeedStre_Wrap" >
            <InlineStack>
                <Box>
                    <BlockStack>
                        <Text>
                            Store Speed Performance
                        </Text>
                        <Card>
                          <InlineStack align='space-between' >
                          <BlockStack>
                                <InlineStack>
                                    <Icon
                                        source={ArrowUpIcon}
                                        tone="base"
                                    />
                                    <Text> 49% </Text>
                                    <Icon source={AlertCircleIcon} tone='base' />
                                </InlineStack>
                                <StoreSpeedChart />
                            </BlockStack>
                            <StorePerformance/>
                          </InlineStack>
                        </Card>
                    </BlockStack>
                </Box>
                <Box>

                </Box>
            </InlineStack>
        </Box>
    )
}
