import { Box } from '@shopify/polaris';
import React from 'react';
import { AnalyticsTitle } from './AnalyticsTitle';
import { AnaliticsStoreSpeed } from './AnaliticsStoreSpeed';

const AnalitiscDefault = () => {


    return (
        <Box>
            <AnalyticsTitle/>
            <AnaliticsStoreSpeed/>
        </Box>
    );
};

export default AnalitiscDefault;
