import { Box, Text } from "@shopify/polaris";
import React, { useEffect, useState } from "react";

export default function StorePerformance() {
    return (
        <Box className="bars">
            <Text>
                hllo
            </Text>
        </Box>
    )
}
